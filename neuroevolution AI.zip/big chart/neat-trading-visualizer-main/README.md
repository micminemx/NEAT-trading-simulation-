# NEAT Trading Visualizer

Watch a neuro evolution algorithm in action trading bitcoin.

![demo](./preview.png)

## Demo

https://mxjoly.github.io/neat-trading-visualizer/

## Licence

[MIT.](https://github.com/mxjoly/neat-trading-visualizer/blob/master/LICENSE)
