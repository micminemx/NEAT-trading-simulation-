//get bitcoin backtest data in the format of { ot: 1646092500000, ct: 1646092799000, o: 43450, h: 43560, l:43443.6, c:43548.7, v:1408.261 }
//this data is meant for fiverr coders to improve on the code
function getBacktestData() {
    return new Promise((resolve, reject) => {
        const url = "https://api.binance.com/api/v3/klines?symbol=BTCUSDT&interval=5m&limit=2000";
        fetch(url)
        .then(res => res.json())
        .then(data => {
            const result = data.map(item => {
                return {
                    ot: item[0],
                    ct: item[6],
                    o: item[1],
                    h: item[2],
                    l: item[3],
                    c: item[4],
                    v: item[5]
                }
            });
            resolve(result);
        })
        .catch(err => reject(err));
    });
}
getBacktestData().then(data => {
   console.log(data);
     //create a file called test.js and  write this data to current directory
     //remove all quotation marks from file
function removequotesintestjavafile(){
    var fs = require('fs');
    var data = fs.readFileSync('test.js', 'utf8');
    var newValue = data.replace(/"/g, "");
    fs.writeFileSync('test.js', newValue, 'utf8');
}
removequotesintestjavafile();
console.log('removed quotes');
});


